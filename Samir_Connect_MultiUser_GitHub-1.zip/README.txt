SAMIR CONNECT — نسخة متعددة المستخدمين

مهم جدًا:
GitHub Pages يستضيف الواجهة فقط. هذه النسخة تستخدم Supabase كخدمة الحسابات وقاعدة البيانات.

للتشغيل الحقيقي:
1) أنشئ مشروعًا مجانيًا في Supabase.
2) من SQL Editor الصق محتوى supabase_schema.sql وشغّله.
3) من إعدادات API انسخ Project URL و anon/publishable key.
4) افتح index.html وابحث عن:
   PUT_YOUR_SUPABASE_URL_HERE
   PUT_YOUR_SUPABASE_ANON_KEY_HERE
   واستبدلهما بالقيمتين.
5) ارفع index.html إلى GitHub Repository وفعل GitHub Pages.

بعدها:
- المستخدمون ينشئون حسابات حقيقية.
- تسجيل الدخول حقيقي.
- المنشورات تحفظ في قاعدة بيانات مشتركة.
- كل الزوار يرون المنشورات نفسها.

لا تضع Service Role Key داخل index.html أو GitHub. استخدم فقط المفتاح العام anon/publishable.
